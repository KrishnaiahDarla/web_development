print("LOADING DOTENV")
from dotenv import load_dotenv, find_dotenv
load_dotenv(find_dotenv())
print("DONE LOADING DOTENV")
