Quality Score FlaskWeb App Readme

This project is intended to provide insight in the Flask Web App

Enjoy

@author: krishnaiah darla 
@email: darla.krishna@gmail.com

